import json

def lambda_handler(event, context):
  #VERSION 1 - with version output
  print ('Accessing Knowledge.....')
  print ('Cats are the best!!!')
  return "Code Version 1"